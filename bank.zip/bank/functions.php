<?php
        wp_enqueue_style( 'style', get_stylesheet_uri() );
        wp_enqueue_style( 'slider', get_template_directory_uri() . './assets/css/bootstrap.min.css');
        wp_enqueue_script( 'script', get_template_directory_uri() . './assets/js/bootstrap.min.js', array( 'jquery' ), 1.1, true);