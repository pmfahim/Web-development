<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php wp_head(); ?>
</head>
<body>
    <div class="container mt-3">
    <div class="row"> 
    <div class="col-lg-2">

<img src="assets/images/menu_icon.png" >
</div>
    <div class="col-lg-4">2</div>
    <div class="col-lg-6">3</div>
    </div>
    </div>



    <?php wp_footer(); ?>
</body>
</html>