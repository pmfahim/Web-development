<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  <?php wp_head(); ?>
    
<body>
    <header class="cont mt-3">
    <div class=" top-header ">
    <div class="row"> 

      <div class="col-lg-1">
      <div class="h-menu">
        <?php dynamic_sidebar('topmenuimg');?>
      </div>
      </div>

      <div class="col-lg-4">
        <input type="text" placeholder="search">
      </div>
      <div class="col-lg-7 text-end">
        <a href="#">বাংলা</a>
      </div>
    </div>
    <div class="header-img">
      <?php dynamic_sidebar('bennerimg');?>
    </div>
    </div>
    <!-- header part end -->

    <!-- menu part start -->

    <div class="menu-lo">
        <div class="row">
            
                <div class="col-md-5">
                   
                </div>
                <div class="col-md-7  text-end" >
               <ul  class="menu1">
                <li> <a class="nav-link" href="#">ABOUT US</a></li>
                <li> <a class="nav-link" href="#">MONETARY POLICY</a></li>
                <li> <a class="nav-link" href="#">FINANCIAL SYSTEM</a></li>
                <li> <a class="nav-link" href="#">PUBLICATION</a></li>
               </ul>



             





                </div>
            
        </div>
    </div>
    <!-- menu part end -->
    <!-- slider part start -->
    <div class="row">
        <div class="col-lg-9">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img class="d-block w-100" src="./assets/images/s1.jpg" alt="First slide">
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="./assets/images/s2.jpg" alt="Second slide">
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="./assets/images/f.jpg" alt="Third slide">
                  </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
        </div>
        <div class="col-lg-3 xx">
            <h6  >HONORABLE GOVERNOR</h6>

            <div class="card mb-3" style="max-width: 540px;">
              <div class="row g-0">
                <div class="col-md-5">
                  <img src="./assets/images/abdurrouftalukder.jpg" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-7">
                  <div class="card-body">
                    <h5 class="card-title">MR. ABDUR ROUF TALUKDER</h5>
                    <p class="card-text"><small class="text-muted">HONORABLE GOVERNOR OF BANGLADESH BANK</small></p>
                    <p class="card-text"><small class="text-muted">more...</small></p>

                  </div>
                </div>
              </div>
            </div>

        </div>

    </div>


    <!-- slider part end -->

    <!-- marquee start -->

   <div class="row ">
    <div class="col-lg-2">
      <span class="lab">RECENT NEWS</span>
     
    </div>
    <div class="col-lg-10">
      <marquee width="60%" direction="down" height="30px">
        FEPD Circular No. 02: Interest rate on borrowing from Export Development Fund (EDF)
        PSD Circular No. 01: Providing permission for Card-Based transaction through Contactless payment service by using NFC technology.
        </marquee>
    </div>
   </div>

    <!-- marquee end -->


    <!-- hero p-art start -->
    <section class="hero">
      <div class="row">
        <div class="col-sm-9">
          <div class="row">
            <div class="col-sm-6">

              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 1</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                     
                    </div>
                  </div>
                </div>
              </div>
              
               <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 2</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      
                    </div>
                  </div>
                </div>
              </div> 

            </div>
            <div class="col-sm-6">

              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 3</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      
                    </div>
                  </div>
                </div>
              </div> 

               <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 4</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      
                    </div>
                  </div>
                </div>
              </div> 

            </div>
          </div>
        </div>
        <div class="col-sm-3">

          <h4 class="heading-primary">Customers\' Interest Protection Center(CIPC)</h4>
          <h6>FOR ANY COMPLAINT</h6>
          <div class="rp text-center">
          <h1 >Call: 16236</h1>
          <p>Email: bb.cipc@bb.org.bd</p>
          <p>Download Mobile App</p>
          <p>Submit Online</p>
          
          </div>
          <p class="text-end" >View all →</p>
        </div>
      </div>


      <div class="row">
        <div class="col-sm-9">
          <div class="row">
            <div class="col-sm-6">
              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 5</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      <!-- <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p> -->
                    </div>
                  </div>
                </div>
              </div>      

               <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 6</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      
                    </div>
                  </div>
                </div>
              </div> 

            </div>
            <div class="col-sm-6">

               <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 7</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      
                    </div>
                  </div>
                </div>
              </div> 


              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 8</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                    </div>
                  </div>
                </div>
              </div> 

            </div>
          </div>
        </div>
        <div class="col-sm-3">

          <h4 class="heading-primary">CALL MONEY RATE</h4>
          <h6>FOR ANY COMPLAINT</h6>
          <div class="rp text-center">
          <h6 >09 February, 2023</h6>
          <p>Weighted Average Interest Rate</p>
          <h1>6.08</h1>
          
          </div>
          <p class="text-end" >View all →</p>
            

        </div>
      </div>

      <div class="row">
        <div class="col-sm-9">
          <div class="row">
            <div class="col-sm-6">
              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 9</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      <!-- <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p> -->
                    </div>
                  </div>
                </div>
              </div>      

            </div>
            <div class="col-sm-6">

              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 10</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                    </div>
                  </div>
                </div>
              </div> 

            </div>
          </div>
        </div>
        <div class="col-sm-3">
          
          <h6 class="text-danger" >CALL MONEY RATE</h6>
          <div class="cmtext text-center">
            <p>12 February, 2023</p>
            <p>Weighted Average Interest Rate</p>
            <h1>6.09</h1>
          </div>
          <p class="text-end">View all →</p>
          
        </div>
      </div>


      <div class="row">
        <div class="col-sm-9">
          <div class="row">
            <div class="col-sm-6">
              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 11</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                      <!-- <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p> -->
                    </div>
                  </div>
                </div>
              </div>      

            </div>
            <div class="col-sm-6">

              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <h6 class="card-title mt-1">MONETARY POLICY 12</h6>
                  <div class="col-md-4">
                    
                    <img src="./assets/images/card1.png" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      
                      <p class="card-text">
                        > MPS (January-June 2023) <br>
                        > Monetary Policy<br>
                        > Banknotes & Coins<br>
                        > Repo Reverse Repo Auction
                      </p>
                    </div>
                  </div>
                </div>
              </div> 

            </div>
          </div>
        </div>
        <div class="col-sm-3">
          
          <h6 class="text-danger" >UPCOMING AUCTIONS</h6>

          <div class="row">
            <div class="col-sm-4"><p class="text-center text-success" >BOND</p></div>
            <div class="col-sm-4"><p class="text-center text-primary" >February,2023</p></div>
            <div class="col-sm-4"><img class="img14" src="./assets/images/14.png" alt=""></div>
          </div>

          <div class="row">
            <div class="col-sm-4"><p class="text-center text-success" >BILL</p></div>
            <div class="col-sm-4"><p class="text-center text-primary" >February,2023</p></div>
            <div class="col-sm-4"><img class="img14" src="./assets/images/19.png" alt=""></div>
          </div>


        </div>
      </div>

      <!-- foottop -->
      <div class="foottop">

        <div class="row">
        <div class="col-sm-9">

          <div class="row">
          <div class="col-sm-4">
            <h5>POLICY RATE</h5>

            <table class="table">

    
              <tr>
                <td>Repo Rate</td>
                <td>6.00%</td>
              </tr>
              
              <tr>
                <td>Special Repo Rate</td>
                <td>9.00%</td>
              </tr>
              
              <tr>
                <td>Rev Repo Rate</td>
                <td>4.25%</td>
              </tr>
              
               <tr>
                <td>Bank Rate</td>
                <td>4.00%</td>
              </tr>
            
          </table>

          </div>
          <div class="col-sm-3">

            <h5>RESERVE RATIO</h5>

            <div class="dt">
              <br>
              <p><small>Traditional Banking</small></p>
              <p><small>Islamic Banking</small></p>
              <p><small>Deposit Taker FIs</small></p>
              <p><small>Non Deposit Taker FIs</small></p>
              <p><small></small></p>
              <p class="text-danger" ><small>*Last update: 30.06.2019</small></p>
            </div>
          </div>
          <div class="col-sm-1 mt-5">

            <p><small> <b>SLR</b></small></p>
            <p><small>13%</small></p>
            <p><small>5.5%</small></p>
            <p><small>5%</small></p>
            <p><small>2.5%</small></p>


          </div>

          <div class="col-sm-1 mt-5 ">

            <p><small> <b>CRR</b></small></p>
            <p><small>4.0%</small></p>
            <p><small>4.0%</small></p>
            <p><small>1.5%</small></p>

          </div>
          <div class="col-sm-3">


            <h5>INTER-BANK EXCHANGE RATE</h5>
            <div class="row">
              <div class="col-sm-4 text-center">
                <p><b> <small>CURRENCY</small></b></p>
                <p> <small>USD</small></p>
              </div>

              <div class="col-sm-4 text-end">
                <p><b> <small>LOWEST</small></b></p>
                <p><small>106.6500</small></p>
              </div>

              <div class="col-sm-4 text-center">
                <p><b> <small>HIGHEST</small></b></p>
                <p><small>107.0000</small></p>
              </div>
              
            </div>

            <p class="text-danger"><small>*Last update: 12th February, 2023</small></p>
            <p class="text-danger"><small>*[Source: BAFEDA]</small></p>

            <button type="button" class="btn btn-success">READ MORE</button>

          </div>



          </div>

        </div>
        <div class="col-sm-3">

          <img src="./assets/images/national-helpline.jpg" alt="">

        </div>
      </div>

      <!-- footer part start -->

      <div class="footer">
        <div class="row mt-5">
          <div class="col-sm-4">
            <h6 class="">CONTACT</h6>

            <img src="./assets/images/l,o.png" height="25" width="25" alt="">
            <span>Bangladesh Bank, Motijheel, Dhaka</span>
            <br>
            <img src="./assets/images/phone1.png" height="25" width="25" alt="">
            <span> Phone: +880-255665001-6</span>
            <br>
            <img src="./assets/images/mail.png" height="25" width="25" alt="">
            <span>E-mail: webmaster@bb.org.bd</span>


            <div class="op"><span>Contact for other purposes</span></div>
            
          </div>
          <div class="col-sm-4">

            <h6>USEFUL LINKS</h6>
            <span>> Payment Systems</span> <br>
            <span>> Regulations And Guidelines</span> <br>
            <span>> Currency Museum</span> <br>
            <span>> SAARC Finance</span> <br>
            <span>> NRB Database</span> <br>
            <span>> Financial Literacy</span> <br>
            <span>> National ICT Policy</span>
          </div>
          <div class="col-sm-4">
            <h6>STAY CONNECTED</h6>
          </div>
        </div>
        <div class="top-line">
          <div class="row">
            <div class="col-sm-12">
              <ul class="info_list">
                <li class="info_list_item1">Home</li>
                <li class="info_list_item">Sitemap</li>
                <li class="info_list_item">Feedback</li>

              </ul>
            </div>

            <span><b style="font-weight: 600;">Disclaimer:</b> 	While every effort is made to ensure accuracy of the information in this website, Bangladesh Bank assumes no responsibility for any damages or losses to users resulting from any error/omission/inadvertent alteration in information provided by this website.</span>
          </div>
        </div>


      </div>
      <!-- footer part end -->

      </div>










      
    </section>
    <!-- hero p-art end -->



</header>



    <?php wp_footer(); ?>
</body>
</html>