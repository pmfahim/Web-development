<?php
        wp_enqueue_style( 'style', get_stylesheet_uri() );
        wp_enqueue_style( 'slider', get_template_directory_uri() . './assets/css/bootstrap.min.css');
        wp_enqueue_script( 'script', get_template_directory_uri() . './assets/js/bootstrap.min.js', array( 'jquery' ), 1.1, true);


        add_theme_support( 'custom-logo' );
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );


        register_sidebar([
		'name' => 'Top Menu Image',
		'id' => 'topmenuimg',
		'description' => '',
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	]);
        register_sidebar([
		'name' => 'Benner Image',
		'id' => 'bennerimg',
		'description' => '',
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	]);
        register_sidebar([
		'name' => 'Benner Image',
		'id' => 'bennerimg',
		'description' => '',
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	]);