<?php
    wp_enqueue_style( 'style-name', get_stylesheet_uri() );
    wp_enqueue_style( 'boot', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
    wp_enqueue_script( 'custom-script', get_template_directory_uri() . '/assets/css/js/custom_script.js', array( 'jquery' ) );


    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'post-thumbnails' );


    register_nav_menus([
        'TM'=>'primary',
        'FM'=>'footer'
    ]);

    register_sidebar([
        'name'=>'Banner',
        'id'=>'banner',
        'before_widget'=>'',
        'after_widget'=>'',
    ])

?>